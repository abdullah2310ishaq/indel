"use client"

interface HeroSectionProps {
  title: string
  subtitle?: string
}

const HeroSection = ({ title, subtitle }: HeroSectionProps) => {
  return (
    <section className="relative overflow-hidden py-12 md:py-16">
      {/* Background Gradient */}
      <div className="absolute inset-0 z-0">
        <div className="h-full w-full bg-gradient-to-b from-[#5a50a3] via-[#8a82c5] to-white"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center text-white max-w-5xl">
        <h1 className="text-xl md:text-2xl font-bold mb-3 leading-tight">{title}</h1>
        {subtitle && <p className="text-sm md:text-base max-w-2xl mx-auto opacity-90 mb-8">{subtitle}</p>}

        {/* Image Card */}
        <div className="mx-auto bg-white rounded-md shadow-md overflow-hidden">
          <div className="relative overflow-hidden">
            <img
              src="/pic1.png"
              alt="Hero Screenshot"
              className="w-full h-auto object-cover"
              style={{ maxHeight: "350px" }}
            />
          </div>
          <div className="p-4 bg-gray-50 text-left">
            <h2 className="text-base font-semibold text-gray-800 mb-2">Your Security Solution</h2>
            <p className="text-xs text-gray-700">
              INDEL provides a comprehensive solution for security companies with advanced scheduling, monitoring, and
              reporting features.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}

export default HeroSection
