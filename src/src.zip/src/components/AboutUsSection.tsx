"use client"

const AboutUsSection = () => {
  return (
    <section className="bg-gray-50 text-center px-4 py-10 text-xs text-gray-700 leading-relaxed">
      {/* Header Banner */}
      <div className="bg-[#5a50a3] py-4 relative text-white mb-8">
        <h2 className="text-lg font-bold">About Us</h2>
        {/* Slanted Bottom Edge */}
        <div
          className="absolute bottom-0 left-0 right-0 h-4 bg-gray-50"
          style={{
            clipPath: "polygon(0 100%, 100% 100%, 100% 0, 50% 100%, 0 0)",
          }}
        ></div>
      </div>

      {/* Content */}
      <div className="container mx-auto max-w-3xl">
        <p className="mb-4">
          INDEL is the next-generation of web-based Application for security companies, conceived with passion and with
          a meticulous focus on the Security Industry. INDEL application offers creative pros exactly what Security
          Companies need—sophisticated reporting, accuracy in every functionality, blazing speed, and unrivalled
          compatibility. We don't do any yearly contracts and charge only monthly subscriptions — it's how a business
          application should be.
        </p>
        <p className="italic">
          Indel is a project by Fiksu Solutions Limited. Fiksu Solutions Limited is an I.T firm specialized in
          developing I.T systems for businesses.
        </p>
      </div>
    </section>
  )
}

export default AboutUsSection
