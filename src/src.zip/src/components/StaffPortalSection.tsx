"use client"

import { useEffect, useState } from "react"

const StaffPortalSection = () => {
  const portalFeatures = [
    "View their rosters",
    "Confirm their shifts",
    "View site/shift instructions",
    "Give their availability",
    "View their personal details",
    "Apply for available shifts",
    "Send annual leave requests",
  ]

  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  return (
    <section className="py-10 bg-[#5a50a3] text-white relative overflow-hidden">
      {/* Decorative background circles */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -left-20 top-0 w-40 h-40 rounded-full bg-[#6b62b5] opacity-10" />
        <div className="absolute left-0 top-24 w-32 h-32 rounded-full bg-[#7c74c6] opacity-10" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <h2 className="text-lg font-bold text-center mb-8">Mobile Friendly Staff Portal</h2>

        <div className="grid md:grid-cols-2 gap-8 items-center">
          {/* Left Side: Portal Screenshot Image */}
          <div className="flex justify-center">
            <div className="rounded-md overflow-hidden shadow-md">
              <img
                src="pic5.png"
                alt="Staff Portal"
                className="w-full h-auto object-contain"
                style={{ maxHeight: "250px" }}
              />
            </div>
          </div>

          {/* Right Side: Feature List */}
          <div>
            <p className="text-sm mb-3">Our staff portal is fully mobile-friendly. Staff can use their portal to:</p>
            <ul className="space-y-2 text-xs">
              {portalFeatures.map((feature, index) => (
                <li key={index} className="flex items-start">
                  <span className="text-white mr-2 flex-shrink-0 mt-0.5">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-3 w-3"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                      />
                    </svg>
                  </span>
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}

export default StaffPortalSection
